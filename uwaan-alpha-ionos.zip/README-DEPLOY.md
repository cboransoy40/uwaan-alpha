# Deploy UWAAN Alpha

Target: https://alfa.uwaan.com/

1. Extract this archive and commit the public/ folder to the alpha's GitHub
   repository. In IONOS Deploy Now, connect that repository as a static site
   and configure the deployment directory to public/. No application build,
   Node runtime, database credentials, or home-server access are required.
2. Open the IONOS preview URL. Check the county map, ZIP hover and click, and
   Focus Mode charts if present. If Area Quality is installed, change a
   criterion and verify that both the ranking and map markers update.
   Check that the browser console shows no failed asset or data requests.
3. In the alpha project's production deployment, assign alfa.uwaan.com and
   confirm HTTPS. Serve the CONTENTS of public/ at the subdomain root.
   The URL should not include /public/. Use the alpha-specific project and
   hostname so deployment is independent from the main UWAAN website.

The map uses external mapping assets already referenced by the existing site.
JSON and GeoJSON under public/data/ are downloaded by visitors' browsers.
Future dataset updates are new static deployments.
