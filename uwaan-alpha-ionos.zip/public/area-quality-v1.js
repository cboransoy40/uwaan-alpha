(() => {
  'use strict';

  const metrics = [
    { label: 'Population', field: 'population', description: 'Total population', format: 'count' },
    { label: 'Income', field: 'median_household_income', description: 'Median household income', format: 'money' },
    { label: 'Education', field: 'bachelors_or_higher_pct', description: 'Bachelor’s degree or higher (age 25+)', format: 'percent' },
    { label: 'Housing', field: 'homeownership_rate_pct', description: 'Owner-occupied share of occupied housing', format: 'percent' }
  ];
  const count = new Intl.NumberFormat('en-US');
  const money = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  const scoreFormat = new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 });
  const valid = (value, metric) => Number.isFinite(value) && value >= 0 && (metric.format !== 'percent' || value <= 100);
  const format = (value, metric) => metric.format === 'money' ? money.format(value) :
    metric.format === 'percent' ? value.toFixed(2) + '%' : count.format(value);
  const dataPath = '/data/demographics_2024.geojson';
  const outlineId = 'area-quality-leaders';
  const fillId = 'area-quality-fill';
  const hoverId = 'area-quality-hover';
  const markerList = [];
  const dom = (tag, className, value) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined) node.textContent = value;
    return node;
  };

  // Midrank percentiles keep tied observations equal, including capped ACS values.
  function percentiles(areas, metric) {
    const sorted = areas.filter(area => valid(area[metric.field], metric))
      .sort((a, b) => a[metric.field] - b[metric.field]);
    const result = new Map();
    for (let start = 0; start < sorted.length;) {
      let end = start + 1;
      while (end < sorted.length && sorted[end][metric.field] === sorted[start][metric.field]) end++;
      const score = sorted.length === 1 ? 50 : 100 * (start + end - 1) / (2 * (sorted.length - 1));
      for (let i = start; i < end; i++) result.set(sorted[i].zcta, score);
      start = end;
    }
    return result;
  }

  // Find an interior label position on a horizontal scanline through the largest component.
  function areaCenter(geometry) {
    const polygons = geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.coordinates;
    const area = ring => Math.abs(ring.reduce((sum, p, i) => {
      const q = ring[(i + 1) % ring.length];
      return sum + p[0] * q[1] - q[0] * p[1];
    }, 0));
    const rings = polygons.reduce((best, polygon) => area(polygon[0]) > area(best[0]) ? polygon : best);
    const ys = rings[0].map(p => p[1]);
    const mid = (Math.min(...ys) + Math.max(...ys)) / 2;
    let width = 0, anchor = rings[0][0];
    for (const fraction of [0.5, 0.35, 0.65]) {
      const lat = fraction === 0.5 ? mid : Math.min(...ys) + fraction * (Math.max(...ys) - Math.min(...ys));
      const cuts = [];
      for (const ring of rings) {
        for (let i = 1; i < ring.length; i++) {
          const [x1, y1] = ring[i - 1], [x2, y2] = ring[i];
          if ((y1 > lat) !== (y2 > lat)) cuts.push(x1 + (lat - y1) * (x2 - x1) / (y2 - y1));
        }
      }
      cuts.sort((a, b) => a - b);
      for (let i = 0; i + 1 < cuts.length; i += 2) {
        if (cuts[i + 1] - cuts[i] <= width) continue;
        width = cuts[i + 1] - cuts[i];
        anchor = [(cuts[i] + cuts[i + 1]) / 2, lat];
      }
    }
    return anchor;
  }

  function mount(data) {
    const originalMap = document.getElementById('map');
    const main = originalMap.parentElement;
    const legacy = main.querySelector('aside');
    const search = document.getElementById('search');
    if (!legacy || !search) throw Error('Explore layout unavailable');
    const geometry = new Map(data.features.map(feature => [feature.properties.zcta, feature.geometry]));
    const years = data.features.map(feature => feature.properties.year).filter(Number.isInteger);
    if (!years.length) throw Error('Missing ACS release year');
    const release = Math.max(...years);
    const areas = data.features.map(feature => feature.properties)
      .filter(area => area.year === release && Number.isFinite(area.population) && area.population > 0);
    if (!areas.length) throw Error('No inhabited areas in the ACS release');
    const scores = new Map(metrics.map(metric => [metric.field, percentiles(areas, metric)]));
    const eligibleByID = new Map(areas.map(area => [area.zcta, area]));

    const left = dom('section', 'aq-sidebar aq-filters');
    left.setAttribute('aria-label', 'Area quality criteria');
    const right = dom('section', 'aq-sidebar aq-results');
    right.setAttribute('aria-label', 'Area quality rankings');
    const checklist = dom('fieldset', 'aq-checklist');
    checklist.append(dom('legend', '', 'Compare by'));
    const searchLabel = dom('label', 'aq-search-label', 'Find a ZIP / ZCTA');
    searchLabel.htmlFor = search.id;
    const searchSlot = dom('div', 'aq-search');
    searchSlot.append(searchLabel);
    const checks = metrics.map(metric => {
      const input = dom('input');
      input.type = 'checkbox';
      input.checked = true;
      const label = dom('label', 'aq-check');
      const copy = dom('span');
      copy.append(dom('strong', '', metric.label), dom('small', '', metric.description));
      label.append(input, copy);
      checklist.append(label);
      return { input, metric };
    });
    left.append(checklist, searchSlot);
    const status = dom('p', 'aq-status');
    status.setAttribute('role', 'status');
    const fitButton = dom('button', 'aq-fit', 'Show leaders on map');
    fitButton.type = 'button';
    const list = dom('ol', 'aq-list');
    const coverage = dom('details', 'aq-coverage');
    coverage.append(dom('summary', '', 'Data coverage & scoring'), dom('p', '',
      `U.S. Census Bureau ACS ${release} 5-Year Estimates. Each selected metric contributes equally through its percentile among covered, inhabited ZCTAs with a valid value. A region needs a value for every selected metric. Tied values share the same percentile. ZIP order breaks ties in the display.`));
    right.append(dom('h2', '', 'Area Quality'), status, fitButton, list, coverage);

    map.addSource('area-quality', { type: 'geojson', data });
    const empty = ['==', ['get', 'zcta'], ''];
    map.addLayer({ id: fillId, source: 'area-quality', type: 'fill', filter: empty,
      paint: { 'fill-color': '#a3e635', 'fill-opacity': 0.21 } });
    map.addLayer({ id: outlineId, source: 'area-quality', type: 'line', filter: empty,
      paint: { 'line-color': '#b6f34a', 'line-width': 1.7, 'line-opacity': 0.84 } });
    map.addLayer({ id: hoverId, source: 'area-quality', type: 'line', filter: empty,
      paint: { 'line-color': '#d9ff92', 'line-width': 3.2 } });

    let leaders = [];
    const highlight = zcta => map.setFilter(hoverId, ['==', ['get', 'zcta'], zcta || '']);
    function fit() {
      if (!leaders.length) return;
      const bounds = new maplibregl.LngLatBounds();
      function extend(item) {
        if (typeof item[0] === 'number') bounds.extend(item);
        else item.forEach(extend);
      }
      leaders.forEach(entry => extend(geometry.get(entry.area.zcta).coordinates));
      const padding = Math.min(48, Math.floor(Math.min(originalMap.clientWidth, originalMap.clientHeight) / 7));
      map.fitBounds(bounds, { padding, maxZoom: 11, duration: matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 600 });
    }

    // Keep the existing map selection and Focus Mode entry point.
    const existingShow = show;
    show = function (properties) {
      if (!window.UWAANFocus?.open) {
        main.classList.add('aq-area-detail');
        map.resize();
      }
      existingShow(properties);
    };
    const back = dom('button', 'aq-fit aq-back', '← Back to Area Quality');
    back.type = 'button';
    back.addEventListener('click', () => {
      main.classList.remove('aq-area-detail');
      map.resize();
    });
    legacy.prepend(back);

    function render() {
      const selected = checks.filter(({ input }) => input.checked).map(({ metric }) => metric);
      const entries = selected.length ? [...eligibleByID.values()].flatMap(area => {
        const parts = selected.map(metric => ({ metric, score: scores.get(metric.field).get(area.zcta) }));
        if (parts.some(part => part.score === undefined)) return [];
        return [{ area, parts, score: parts.reduce((sum, part) => sum + part.score, 0) / parts.length }];
      }) : [];
      entries.sort((a, b) => b.score - a.score || a.area.zcta.localeCompare(b.area.zcta));
      leaders = entries.slice(0, 10);
      status.textContent = !selected.length ? 'Select a criterion to rank areas.' : !leaders.length ?
        'No areas have data for every selected criterion.' :
        `Top ${leaders.length} of ${entries.length} eligible areas · Based on your selected criteria`;
      fitButton.hidden = !leaders.length;
      list.replaceChildren();
      highlight('');
      markerList.splice(0).forEach(marker => marker.remove());
      const filter = ['in', ['get', 'zcta'], ['literal', leaders.map(entry => entry.area.zcta)]];
      map.setFilter(fillId, filter);
      map.setFilter(outlineId, filter);

      leaders.forEach(({ area, parts, score }, i) => {
        const rank = i + 1;
        const name = area.display_name || area.postal_city || 'ZIP ' + area.zcta;
        const marker = dom('span', 'aq-marker', rank);
        marker.setAttribute('aria-hidden', 'true');
        markerList.push(new maplibregl.Marker({ element: marker })
          .setLngLat(areaCenter(geometry.get(area.zcta))).addTo(map));

        const item = dom('li', 'aq-row');
        const open = dom('button', 'aq-open');
        open.type = 'button';
        const label = dom('span', 'aq-place');
        label.append(dom('strong', '', name), dom('small', '', 'ZCTA ' + area.zcta));
        const value = dom('span', 'aq-score', scoreFormat.format(score));
        value.append(dom('small', '', '/100'));
        open.append(dom('span', 'aq-rank', rank), label, value);
        open.addEventListener('click', () => select(area.zcta));
        item.addEventListener('pointerenter', () => highlight(area.zcta));
        item.addEventListener('pointerleave', () => highlight(''));
        item.addEventListener('focusin', () => highlight(area.zcta));
        item.addEventListener('focusout', event => {
          if (!item.contains(event.relatedTarget)) highlight('');
        });
        const breakdown = dom('details', 'aq-breakdown');
        breakdown.append(dom('summary', '', 'Score breakdown'));
        const partsList = dom('ul');
        parts.forEach(({ metric, score: percentile }) => {
          const row = dom('li');
          row.append(dom('span', '', metric.description), dom('strong', '', format(area[metric.field], metric)),
            dom('small', '', `${scoreFormat.format(percentile)} percentile score · +${scoreFormat.format(percentile / parts.length)} points`));
          partsList.append(row);
        });
        breakdown.append(partsList);
        item.append(open, breakdown);
        list.append(item);
      });
    }

    main.prepend(left);
    main.append(right);
    searchSlot.append(search);
    main.classList.add('aq-explore');
    const observer = new ResizeObserver(() => map.resize());
    observer.observe(originalMap);
    checks.forEach(({ input }) => input.addEventListener('change', () => { render(); fit(); }));
    fitButton.addEventListener('click', fit);
    render();
  }

  async function start() {
    try {
      const response = await fetch(dataPath);
      if (!response.ok) throw Error('GeoJSON HTTP ' + response.status);
      const data = await response.json();
      if (data.type !== 'FeatureCollection' || !data.features?.length) throw Error('Invalid ZCTA data');
      if (!map.getLayer('fills')) {
        await new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            map.off('styledata', ready);
            reject(Error('Explore ZCTA layer did not load'));
          }, 15000);
          function ready() {
            if (!map.getLayer('fills')) return;
            clearTimeout(timer);
            map.off('styledata', ready);
            resolve();
          }
          map.on('styledata', ready);
        });
      }
      mount(data);
    } catch (error) {
      console.error('Area Quality:', error);
    }
  }

  if (map.loaded()) start();
  else map.once('load', start);
})();
