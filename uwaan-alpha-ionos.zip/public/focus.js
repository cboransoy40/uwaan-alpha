(() => {
'use strict';
const HIST='/data/demographics_history.json',GEO='/data/demographics_2024.geojson';
const specs={
 Population:{key:'population',unit:'count',fields:[['Age 0–17','age_0_17','count'],['Age 18–34','age_18_34','count'],['Age 35–64','age_35_64','count'],['Age 65+','age_65_plus','count']]},
 Income:{key:'median_household_income',unit:'money',fields:[['Per capita income','per_capita_income','money'],['Median household income','median_household_income','money']]},
 Education:{key:'bachelors_or_higher_pct',unit:'pct',fields:[["Bachelor's degree",'bachelors_degree','count'],['Postgraduate degree','postgraduate_degree','count'],['Associate degree','associate_degree','count'],['Age 25+ population','education_population_25plus','count']]},
 Employment:{key:'unemployment_rate_pct',unit:'pct',fields:[['Civilian labor force','civilian_labor_force','count'],['Employed','employed','count'],['Unemployed','unemployed','count']]},
 Housing:{key:'homeownership_rate_pct',unit:'pct',fields:[['Total housing units','total_housing_units','count'],['Owner occupied','owner_occupied','count'],['Renter occupied','renter_occupied','count'],['Vacant units','vacant_units','count']]},
 Migration:{key:'mobility_rate_pct',unit:'pct',fields:[['Moved within county','moved_within_county','count'],['From other CA county','from_other_ca_county','count'],['From another state','from_other_state','count'],['From abroad','from_abroad','count']]}
};
const cards=[['Population','population','count'],['Median Household Income','median_household_income','money'],["Bachelor's Degree or Higher",'bachelors_or_higher_pct','pct'],['Unemployment Rate','unemployment_rate_pct','pct']];
let rows=[],geo=null,active=null,focusMap=null,labelMarker=null,tab='Population',year=2024,loading=null; // UWAAN_FOCUS_MARKER_FIX_V11
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;}
function valid(n){return n!==null&&n!==undefined&&Number.isFinite(Number(n))&&Number(n)>=0;}
function fmt(n,t){if(!valid(n))return 'N/A';let v=Number(n);return t==='pct'?v.toFixed(2)+'%':t==='money'?'$'+Math.round(v).toLocaleString('en-US'):Math.round(v).toLocaleString('en-US');}
function getRows(){return rows.filter(r=>String(r.zcta)===String(active?.zcta)).sort((a,b)=>a.year-b.year);}
function rec(){return getRows().find(r=>Number(r.year)===year);}
function latestRec(){return getRows().filter(r=>Number.isFinite(Number(r.year))).at(-1);}
// UWAAN_FOCUS_V12: Overview always uses latest available local records, not the historical year selector.
function delta(k,t,until=year){let rs=getRows().filter(r=>valid(r[k])&&r.year<=until);if(rs.length<2)return 'Historical comparison unavailable';let a=rs[0],b=rs[rs.length-1];if(a.year===b.year)return 'Historical comparison unavailable';let d=Number(b[k])-Number(a[k]);if(t==='pct')return `${d>=0?'+':''}${d.toFixed(2)} pp since ${a.year}`;if(!Number(a[k]))return 'Historical comparison unavailable';return `${d>=0?'+':''}${(d/Number(a[k])*100).toFixed(1)}% since ${a.year}`;}
function spark(k,until=year){let rs=getRows().filter(r=>r.year<=until&&valid(r[k]));if(rs.length<2)return '';let a=rs.map(r=>Number(r[k])),lo=Math.min(...a),hi=Math.max(...a);if(lo===hi)hi=lo+1;let x=i=>6+i/Math.max(rs.length-1,1)*288,y=v=>48-(v-lo)/(hi-lo)*40;let pts=a.map((v,i)=>`${x(i).toFixed(2)},${y(v).toFixed(2)}`).join(' ');return `<svg viewBox="0 0 300 56" preserveAspectRatio="none" aria-hidden="true"><line x1="0" y1="52" x2="300" y2="52" stroke="#354d38"/><polyline points="${pts}" fill="none" stroke="#b4f447" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"/></svg>`;}
function cardDOM(cfg){let [title,key,unit]=cfg,r=latestRec();let d=el('article','uf-card');d.append(el('div','uf-metric-title',title),el('div','uf-value',fmt(r?.[key],unit)),el('div','uf-delta',delta(key,unit,r?.year)));let s=el('div','uf-spark');s.innerHTML=spark(key,r?.year);d.append(s);return d;}
function chartDOM(){
 const spec=specs[tab],rs=getRows().filter(r=>r.year<=year&&valid(r[spec.key]));
 const box=document.getElementById('uf-chart');box.replaceChildren();
 if(rs.length<2){box.textContent='Not enough historical observations for this period.';return;}
 const vals=rs.map(r=>Number(r[spec.key]));let low=Math.min(...vals),high=Math.max(...vals);
 if(low===high)high=low+1;
 const x=y=>45+(y-2011)/13*950,yy=v=>175-(v-low)/(high-low)*135;
 const points=rs.map(r=>({year:Number(r.year),value:Number(r[spec.key]),cx:x(r.year),cy:yy(Number(r[spec.key]))}));
 const poly=points.map(p=>`${p.cx.toFixed(1)},${p.cy.toFixed(1)}`).join(' ');
 const svg=`<svg viewBox="0 0 1040 210" preserveAspectRatio="none" role="img" aria-label="${tab} historical trend"><line x1="45" x2="998" y1="175" y2="175" stroke="#425446"/><line x1="45" x2="998" y1="108" y2="108" stroke="#304234" stroke-dasharray="4 6"/><line x1="45" x2="998" y1="40" y2="40" stroke="#304234" stroke-dasharray="4 6"/><text x="0" y="44">${fmt(high,spec.unit)}</text><text x="0" y="177">${fmt(low,spec.unit)}</text><polyline points="${poly}" stroke="#b4f447" stroke-width="3" fill="none" stroke-linejoin="round"/>${points.map(p=>`<circle cx="${p.cx.toFixed(1)}" cy="${p.cy.toFixed(1)}" r="4" fill="#b4f447"><title>${p.year}: ${fmt(p.value,spec.unit)}</title></circle>`).join('')}<line id="uf-hover-line" x1="0" x2="0" y1="37" y2="175" stroke="#c9fa83" stroke-width="1.3" stroke-dasharray="3 5" opacity="0"/><circle id="uf-hover-dot" cx="0" cy="0" r="7" fill="#d4ff7e" stroke="#18280f" stroke-width="2" opacity="0"/><text x="45" y="199">2011</text><text x="907" y="199">${year}</text></svg>`;
 box.innerHTML=svg;
 const svgEl=box.querySelector('svg');
 const tooltip=el('div','uf-chart-tip');tooltip.hidden=true;box.appendChild(tooltip);
 const line=box.querySelector('#uf-hover-line'),dot=box.querySelector('#uf-hover-dot');
 function update(e){
   const r=svgEl.getBoundingClientRect();if(!r.width||!r.height)return;
   const mouseX=(e.clientX-r.left)/r.width*1040;
   const nearest=points.reduce((a,b)=>Math.abs(b.cx-mouseX)<Math.abs(a.cx-mouseX)?b:a);
   line.setAttribute('x1',nearest.cx);line.setAttribute('x2',nearest.cx);line.setAttribute('opacity','1');
   dot.setAttribute('cx',nearest.cx);dot.setAttribute('cy',nearest.cy);dot.setAttribute('opacity','1');
   tooltip.replaceChildren(el('strong','',String(nearest.year)),el('span','',fmt(nearest.value,spec.unit)));
   tooltip.style.left=`${Math.max(62,Math.min(box.clientWidth-62,nearest.cx/1040*r.width))}px`;
   tooltip.style.top=`${Math.max(9,Math.min(box.clientHeight-54,nearest.cy/210*r.height-59))}px`;
   tooltip.hidden=false;
 }
 svgEl.addEventListener('pointermove',update);
 svgEl.addEventListener('pointerenter',update);
 svgEl.addEventListener('pointerleave',()=>{tooltip.hidden=true;line.setAttribute('opacity','0');dot.setAttribute('opacity','0');});
}
function render(){if(!active)return;let r=rec();document.getElementById('uf-title').textContent=active.display_name||('ZIP '+active.zcta);document.getElementById('uf-location').textContent=`ZIP / ZCTA ${active.zcta} · San Diego County`;document.getElementById('uf-map-name').textContent=active.display_name||('ZIP '+active.zcta);document.getElementById('uf-map-zip').textContent=active.zcta;document.getElementById('uf-year').value=String(year);
 const c=document.getElementById('uf-cards'),right=document.getElementById('uf-cards-right');c.replaceChildren(cardDOM(cards[0]),cardDOM(cards[2]));right.replaceChildren(cardDOM(cards[1]),cardDOM(cards[3]));
 document.getElementById('uf-chart-title').textContent=`${tab} Trend · 2011–${year}`;chartDOM();
 document.querySelectorAll('.uf-tab').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===tab)));
 let det=document.getElementById('uf-details-grid');det.replaceChildren();for(let [label,k,unit] of specs[tab].fields){let e=el('div','uf-detail');e.append(el('small','',label),el('strong','',fmt(r?.[k],unit)));det.append(e);}
 let note=document.getElementById('uf-note');note.textContent=!r?'No ACS record for this ZCTA and year. Some ZCTAs changed between ACS vintages.':`Source: ACS 5-Year estimate for ${year}. Annual releases overlap, so yearly points are not independent observations. 2020–2021 ZCTA geography changes may limit comparisons. ZIP/ZCTA boundaries are not neighborhood boundaries. ${tab==='Income'?'Dollar values are nominal, not inflation-adjusted.':''}`;
}
function coordinates(node,out){if(!Array.isArray(node))return;if(typeof node[0]==='number'&&typeof node[1]==='number'){out.push(node);return;}for(let v of node)coordinates(v,out);}
function mapView(){if(!active||!geo)return;let feature=geo.features.find(f=>String(f.properties.zcta)===String(active.zcta));if(!feature)return;
 const boundsPoints=[];coordinates(feature.geometry.coordinates,boundsPoints);if(!boundsPoints.length)return;const xs=boundsPoints.map(p=>p[0]),ys=boundsPoints.map(p=>p[1]),bb=[[Math.min(...xs),Math.min(...ys)],[Math.max(...xs),Math.max(...ys)]]; const labelCenter=[(bb[0][0]+bb[1][0])/2,(bb[0][1]+bb[1][1])/2];
 if(!focusMap){focusMap=new maplibregl.Map({container:'uf-map',style:'/styles/uwaan-dark.json',center:[-117.14,32.88],zoom:9,pitch:37,bearing:0,attributionControl:false});focusMap.on('load',()=>{focusMap.addSource('uf-zctas',{type:'geojson',data:geo});focusMap.addLayer({id:'uf-other',type:'fill',source:'uf-zctas',filter:['!=',['get','zcta'],String(active?.zcta)],paint:{'fill-color':'#020b08','fill-opacity':0.73}});focusMap.addLayer({id:'uf-target-fill',type:'fill',source:'uf-zctas',filter:['==',['get','zcta'],String(active?.zcta)],paint:{'fill-color':'#a3e635','fill-opacity':0.36}});focusMap.addLayer({id:'uf-target-glow',type:'line',source:'uf-zctas',filter:['==',['get','zcta'],String(active?.zcta)],paint:{'line-color':'#a3e635','line-width':8,'line-blur':5,'line-opacity':0.65}});focusMap.addLayer({id:'uf-target-border',type:'line',source:'uf-zctas',filter:['==',['get','zcta'],String(active?.zcta)],paint:{'line-color':'#c5ff58','line-width':3,'line-opacity':1}});if(!labelMarker){const labelEl=document.querySelector('#uwaan-focus .uf-map-label');labelMarker=new maplibregl.Marker({element:labelEl,anchor:'center'}).setLngLat(labelCenter).addTo(focusMap);}else{labelMarker.setLngLat(labelCenter);}
focusMap.resize();focusMap.fitBounds(bb,{padding:55,maxZoom:12,pitch:37,bearing:0,duration:0});});}
 else{let ids=['uf-other','uf-target-fill','uf-target-glow','uf-target-border'];for(let id of ids){if(focusMap.getLayer(id))focusMap.setFilter(id,[id==='uf-other'?'!=':'==',['get','zcta'],String(active.zcta)]);}if(labelMarker)labelMarker.setLngLat(labelCenter);focusMap.resize();focusMap.fitBounds(bb,{padding:55,maxZoom:12,pitch:37,bearing:0,duration:600});}
}
function hide(){document.getElementById('uwaan-focus').hidden=true;document.body.style.overflow='';if(focusMap)focusMap.resize();}
function showFocus(p){active={zcta:String(p.zcta),display_name:p.display_name||('ZIP '+p.zcta)};year=2024;tab='Population';document.getElementById('uwaan-focus').hidden=false;document.body.style.overflow='hidden';let wait=loading||Promise.resolve();wait.then(()=>{if(document.getElementById('uwaan-focus').hidden)return;render();mapView();}).catch(e=>{document.getElementById('uf-note').textContent='Could not load data: '+e.message;});}
function setup(){let shell=el('div');shell.id='uwaan-focus';shell.hidden=true;shell.innerHTML=`<div class="uf-top"><div class="uf-brand">UWAAN</div><div class="uf-tag">Neighborhood Intelligence</div><div class="uf-spacer"></div><button type="button" class="uf-back" id="uf-back">← Back to Explore</button></div><main class="uf-shell"><header class="uf-heading"><div class="uf-kicker">SAN DIEGO COUNTY · NEIGHBORHOOD INTELLIGENCE</div><h1 id="uf-title">MIRA MESA</h1><p id="uf-location">ZIP / ZCTA 92126</p><div class="uf-year-wrap"><label for="uf-year">Historical year</label><select id="uf-year"></select></div></header><section class="uf-stage"><div class="uf-column" id="uf-cards"></div><div class="uf-map-card"><div id="uf-map"></div><div class="uf-map-label"><strong id="uf-map-name">MIRA MESA</strong><span id="uf-map-zip">92126</span></div><div class="uf-map-source">MapLibre · OpenFreeMap · © OpenStreetMap contributors</div></div><div class="uf-column" id="uf-cards-right"></div></section><section class="uf-nav"><strong>Historical Analysis</strong><div class="uf-tabs" id="uf-tabs"></div></section><section class="uf-bottom"><article class="uf-trend"><div class="uf-section-title" id="uf-chart-title">Population Trend</div><div class="uf-sub">Historical ACS 5-Year estimates (not independent annual observations)</div><div id="uf-chart"></div></article><article class="uf-details"><div class="uf-section-title">Detailed Indicators</div><div class="uf-sub">Values for the selected region and year</div><div id="uf-details-grid" class="uf-details-grid"></div><div class="uf-note" id="uf-note"></div></article></section></main>`;document.body.append(shell);
 // Move the year selector from the overview into Historical Analysis.
 const yearWrap=document.querySelector('#uwaan-focus .uf-year-wrap');
 document.querySelector('#uwaan-focus .uf-nav').insertBefore(yearWrap,document.getElementById('uf-tabs'));
 const coverage=el('div','uf-coverage','Latest available local estimates · Data coverage');
 coverage.title='Overview uses the latest available ZCTA-level ACS 5-Year release (currently 2024), not real-time 2026 neighborhood observations. County-level 2025/2026 figures are not substituted for ZIP estimates.';
 document.querySelector('#uwaan-focus .uf-heading').appendChild(coverage);
 document.getElementById('uf-back').addEventListener('click',hide);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!shell.hidden)hide();});const ys=document.getElementById('uf-year');for(let y=2024;y>=2011;y--){let opt=document.createElement('option');opt.value=String(y);opt.textContent=String(y);ys.append(opt);}ys.addEventListener('change',()=>{year=Number(ys.value);render();});const ts=document.getElementById('uf-tabs');Object.keys(specs).forEach(t=>{let b=el('button','uf-tab',t);b.type='button';b.dataset.tab=t;b.setAttribute('aria-selected',String(tab===t));b.addEventListener('click',()=>{tab=t;render();});ts.append(b);});
 loading=Promise.all([fetch(HIST).then(r=>{if(!r.ok)throw Error('History HTTP '+r.status);return r.json();}),fetch(GEO).then(r=>{if(!r.ok)throw Error('Geometry HTTP '+r.status);return r.json();})]).then(([h,g])=>{if(!Array.isArray(h)||h.length!==1554)throw Error('Unexpected historical data size');if(!g.features||g.features.length!==116)throw Error('Unexpected geometry count');rows=h;geo=g;});
 // history.js has already wrapped 'show', so preserve that function and its existing data updates.
 const existingShow=show;
 show=function(p){existingShow(p);if(p&&p.zcta)showFocus(p);};
 window.UWAANFocus={open:showFocus,close:hide};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
})();
