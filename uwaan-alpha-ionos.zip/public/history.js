(() => {
'use strict';
const tabs={
  Population:{label:'Population',chart:'population',items:[['Population','population','count'],['Age 0–17','age_0_17','count'],['Age 18–34','age_18_34','count'],['Age 35–64','age_35_64','count'],['Age 65+','age_65_plus','count']]},
  Income:{label:'Income',chart:'median_household_income',items:[['Median household income','median_household_income','money'],['Per capita income','per_capita_income','money']]},
  Education:{label:'Education',chart:'bachelors_or_higher_pct',items:[["Bachelor's or higher",'bachelors_or_higher_pct','pct'],['Education population (25+)','education_population_25plus','count'],['High school diploma only','high_school_diploma_only','count'],['Associate degree','associate_degree','count'],["Bachelor's degree",'bachelors_degree','count'],['Postgraduate degree','postgraduate_degree','count']]},
  Employment:{label:'Employment',chart:'unemployment_rate_pct',items:[['Unemployment rate','unemployment_rate_pct','pct'],['Civilian labor force','civilian_labor_force','count'],['Employed','employed','count'],['Unemployed','unemployed','count']]},
  Housing:{label:'Housing',chart:'homeownership_rate_pct',items:[['Total housing units','total_housing_units','count'],['Occupied units','occupied_units','count'],['Vacant units','vacant_units','count'],['Owner-occupied units','owner_occupied','count'],['Renter-occupied units','renter_occupied','count'],['Homeownership rate','homeownership_rate_pct','pct'],['Vacancy rate','vacancy_rate_pct','pct']]},
  Migration:{label:'Migration',chart:'mobility_rate_pct',items:[['Mobility rate','mobility_rate_pct','pct'],['Population age 1+','mobility_population','count'],['Same house','same_house','count'],['Moved within county','moved_within_county','count'],['From another CA county','from_other_ca_county','count'],['From another state','from_other_state','count'],['From abroad','from_abroad','count']]}
};
let all=[],byZip=new Map(),activeTab='Population',activeYear=2024,activeZip=null;
const controls=document.getElementById('history-controls');
const yearSelect=document.getElementById('history-year');
const tabBox=document.getElementById('history-tabs');
const note=document.getElementById('history-note');
const originalShow=show;
const format=(value,kind)=>{
 if(value===null||value===undefined||!Number.isFinite(Number(value)))return 'N/A';
 const n=Number(value);
 if(n<0)return 'N/A';
 if(kind==='money')return '$'+n.toLocaleString('en-US',{maximumFractionDigits:0});
 if(kind==='pct')return n.toFixed(2)+'%';
 return Math.round(n).toLocaleString('en-US');
};
for(let year=2024;year>=2011;year--){
 const option=document.createElement('option');option.value=String(year);option.textContent=String(year);yearSelect.appendChild(option);
}
Object.keys(tabs).forEach(name=>{
 const button=document.createElement('button');button.type='button';button.className='history-tab';button.textContent=name;
 button.onclick=()=>{activeTab=name;render();};tabBox.appendChild(button);
});
function chart(rows,config){
 const points=rows.filter(r=>Number.isFinite(Number(r[config.chart]))&&r[config.chart]!==null&&Number(r[config.chart])>=0).map(r=>({year:r.year,v:Number(r[config.chart])}));
 if(points.length<2)return '';
 let lo=Math.min(...points.map(x=>x.v)),hi=Math.max(...points.map(x=>x.v));
 if(hi===lo)hi=lo+1;
 const x=year=>28+(year-2011)/13*444;
 const y=v=>120-(v-lo)/(hi-lo)*98;
 const line=points.map(p=>x(p.year).toFixed(1)+','+y(p.v).toFixed(1)).join(' ');
 const dots=points.map(p=>`<circle cx="${x(p.year).toFixed(1)}" cy="${y(p.v).toFixed(1)}" r="3.2" fill="#b4f04a"><title>${p.year}: ${format(p.v,config.items.find(i=>i[1]===config.chart)?.[2]||'count')}</title></circle>`).join('');
 return `<div class="history-chart"><div class="history-chart-title">${config.label} · 2011–2024 trend</div><svg viewBox="0 0 500 148" role="img" aria-label="Historical ${config.label} trend"><line x1="28" x2="472" y1="120" y2="120" stroke="#526455"/><polyline points="${line}" stroke="#b4f04a" stroke-width="2.5" fill="none" stroke-linejoin="round"/>${dots}<text x="28" y="141" fill="#95a895" font-size="12">2011</text><text x="444" y="141" fill="#95a895" font-size="12">2024</text></svg><small>ACS 5-Year estimates · Annual releases overlap; 2020–2021 geography transition may affect comparisons.</small></div>`;
}
function render(){
 if(!activeZip||!byZip.has(activeZip))return;
 const rows=byZip.get(activeZip),record=rows.find(r=>r.year===activeYear);
 tabBox.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.textContent===activeTab));
 const metricBox=document.getElementById('metrics');metricBox.replaceChildren();
 document.getElementById('desc').textContent=`ZIP / ZCTA ${activeZip} · ACS ${activeYear} 5-Year`;
 if(!record){note.textContent='No ACS record for this ZCTA in the selected year. This can reflect changes in ZCTA definitions.';return;}
 note.textContent=(record.comparison_status==='REVIEW_BEFORE_COMPARISON')?'Geography/methodology transition: compare 2020–2021 estimates with caution.':'ACS 5-Year estimates; values describe ZCTA geography, not exact neighborhood boundaries.';
 const config=tabs[activeTab];
 for(const [label,key,kind] of config.items){
  const el=document.createElement('div');el.className='card';
  const l=document.createElement('span');l.textContent=label;
  const v=document.createElement('strong');v.textContent=format(record[key],kind);
  el.append(l,v);metricBox.append(el);
 }
 const box=document.createElement('div');box.innerHTML=chart(rows,config);if(box.firstElementChild)metricBox.append(box.firstElementChild);
}
show=function(p){originalShow(p);activeZip=String(p.zcta);controls.hidden=false;render();};
yearSelect.addEventListener('change',()=>{activeYear=Number(yearSelect.value);render();});
fetch('/data/demographics_history.json').then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json();}).then(rows=>{
 if(!Array.isArray(rows)||rows.length!==1554)throw Error('Unexpected historical record count');
 all=rows;
 for(const r of all){const z=String(r.zcta);if(!byZip.has(z))byZip.set(z,[]);byZip.get(z).push(r);}
 for(const list of byZip.values())list.sort((a,b)=>a.year-b.year);
 note.textContent='Historical data loaded. Select a region on the map.';
 if(activeZip)render();
}).catch(e=>{note.textContent='Historical data unavailable: '+e.message;});
})();
